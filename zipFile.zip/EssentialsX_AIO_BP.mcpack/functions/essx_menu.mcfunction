scriptevent essx:menu
